Hiera Data:
==========

Any hiera data required by your profile is placed in this directory and follow the naming convention:
```
<PROFILE_NAME>.yaml
```
For an example of a hiera data file checkout the 'ntp' branch of this repo
