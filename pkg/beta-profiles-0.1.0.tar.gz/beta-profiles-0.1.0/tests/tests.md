tests:
==========

Profile tests are placed in this directory and follow the naming convention:
```
<PROFILE_NAME>.pp
```
All the test needs to do is to call your profile class.

For an example of a manifest file checkout the 'ntp' branch of this repo
